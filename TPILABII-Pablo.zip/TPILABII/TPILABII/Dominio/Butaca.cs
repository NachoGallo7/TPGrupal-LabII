﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WinFormsTPPrueba.Presentacion;

namespace WinFormsTPPrueba.Dominio
{
    class Butaca
    {
        public int Id_Butaca { get; set; }
        public int Fila { get; set; }
        public int NroButaca { get; set; }
        public Tipos_Butacas Tipo { get; set; }
        public int Id_Sala { get; set; }

        public Butaca(Tipos_Butacas tipo)
        {
            Tipo = tipo;
        }


    }
}
