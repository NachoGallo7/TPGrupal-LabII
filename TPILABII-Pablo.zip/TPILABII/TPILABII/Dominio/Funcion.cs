﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsTPPrueba.Dominio
{
    class Funcion
    {
        public int Id_Funcion { get; set; }
        public int Id_Pelicula { get; set; }
        public int Id_Sala { get; set; }
        public DateTime Dia { get; set; }
        public DateTime Hora { get; set; }
        public decimal Precio { get; set; }

        public Funcion()
        {

        }

    }
}
