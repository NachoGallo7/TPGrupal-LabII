﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsTPPrueba.Presentacion
{
    class Tipos_Butacas
    {
        public int Id { get; set; }
        public string Nombre { get; set; }

        public Tipos_Butacas()
        {
            Nombre = "";
        }
    }
}
