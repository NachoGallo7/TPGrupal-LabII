﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsTPPrueba.Dominio
{
    class Butaca_Funcion
    {
        public int Id { get; set; }
        public Butaca Butaca { get; set; }
        public Funcion Funcion { get; set; }

        //public Reserva Reserva { get; set; }

        public Butaca_Funcion(int id, Butaca butaca, Funcion funcion)
        {
            Id = id;
            Butaca = butaca;
            Funcion = funcion;
        }

    }
}
