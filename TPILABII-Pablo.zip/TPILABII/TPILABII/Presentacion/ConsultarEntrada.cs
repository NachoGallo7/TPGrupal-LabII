﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinFormsTPPrueba.Datos;
using WinFormsTPPrueba.Dominio;

namespace WinFormsTPPrueba.Presentacion
{
    public partial class ConsultarEntrada : Form
    {
        HelperDB ayudante;
        public ConsultarEntrada()
        {
            InitializeComponent();
            ayudante = new HelperDB();
        }

        private void btnConsultar_Click(object sender, EventArgs e)
        {
            
            DataTable tabla = ayudante.Consulta_Comprobantes(dtpFecha1.Value, dtpFecha2.Value, (int)cboClientes.SelectedValue);

            dgvEntradas.DataSource = tabla;

            lblCompras.Text = "Total de compras: " + (dgvEntradas.Rows.Count -1);
            
            
            lblTotal.Text = "Total: $ " + ayudante.Consulta_Total(dtpFecha1.Value, dtpFecha2.Value, (int)cboClientes.SelectedValue);

           
        }

 
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            DatosClientes();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("¿Seguro desea salir?", "Salir", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                this.Close();
        }

        private void ConsultarEntrada_Load(object sender, EventArgs e)
        {
            dtpFecha1.Value = DateTime.Now;
            dtpFecha2.Value = DateTime.Now.AddDays(7);

            ComboClientes();

            DatosClientes();
        }

        private void ComboClientes()
        {
            DataTable tabla = new DataTable();
            tabla = ayudante.ConsultaClientes();
            cboClientes.DataSource = tabla;
            cboClientes.ValueMember = "Id_Cliente";
            cboClientes.DisplayMember = "Cliente";
            cboClientes.DropDownStyle = ComboBoxStyle.DropDownList;
        }

        private void DatosClientes()
        {
            DataRowView cliente = (DataRowView)cboClientes.SelectedItem;

            DateTime fechaNac = Convert.ToDateTime(cliente.Row.ItemArray[4].ToString());
            int codigo = Convert.ToInt32(cliente.Row.ItemArray[0].ToString());

            DataTable tabla = ayudante.ConsultaDatos(codigo);

            txtCorreo.Text = "";
            txtTelefono.Text = "";

            foreach (DataRow fila in tabla.Rows)
            {
                if (fila[1].Equals("Email"))
                {
                    txtCorreo.Text = fila[2].ToString();
                }
                else
                {
                    txtTelefono.Text = fila[2].ToString();
                }
            }

            txtFechaNac.Text = fechaNac.ToString("dd/MM/yyyy");
            
        
        }
    }
}
