﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WinFormsTPPrueba.Dominio;

namespace WinFormsTPPrueba.Datos
{
    class HelperDB
    {
        private SqlConnection cnn;

        public HelperDB()
        {
            cnn = new SqlConnection(@"Data Source=HP15-BS007LA\SQLEXPRESS;Initial Catalog=COMPLEJO_CINE_v3;Integrated Security=True");
        }

        public DataTable ConsultaClientes()
        {
            DataTable tabla = new DataTable();
            cnn.Open();
            SqlCommand cmd = new SqlCommand("Consultar_Clientes", cnn);
            cmd.CommandType = CommandType.StoredProcedure;
            tabla.Load(cmd.ExecuteReader());
            cnn.Close();
            return tabla;
        }

        public DataTable Consulta_Comprobantes(DateTime fecha1, DateTime fecha2, int cliente)
        {
            
            DataTable tabla = new DataTable();
            cnn.Open();
            string sp = "SP_CONSULTAR_PRESUPUESTOS";
            SqlCommand cmd = new SqlCommand(sp, cnn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@fecha1", fecha1);
            cmd.Parameters.AddWithValue("@fecha2", fecha2);
            cmd.Parameters.AddWithValue("@codigo", cliente);
            tabla.Load(cmd.ExecuteReader());
            cnn.Close();

            return tabla;

        }
        public DataTable ConsultaDatos(int codigo)
        {
            DataTable tabla = new DataTable();
            cnn.Open();
            string sp = "SP_CONTACTOS_CLIENTES";
            SqlCommand cmd = new SqlCommand(sp, cnn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@codigo",codigo);
            tabla.Load(cmd.ExecuteReader());
            cnn.Close();

            return tabla;
        }

        public decimal Consulta_Total(DateTime fecha1, DateTime fecha2, int cliente)
        {

            decimal aux=0;
            cnn.Open();
            string sp = "SP_TOTAL_COMPRAS";
            SqlCommand cmd = new SqlCommand(sp, cnn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@fecha1", fecha1);
            cmd.Parameters.AddWithValue("@fecha2", fecha2);
            cmd.Parameters.AddWithValue("@codigo", cliente);
            SqlParameter pOut = new SqlParameter("@total",SqlDbType.Decimal);
            pOut.Direction = ParameterDirection.Output;
            cmd.Parameters.Add(pOut);
            cmd.ExecuteNonQuery();
            cnn.Close();

            aux = Convert.ToDecimal(pOut.Value);
            return aux;

        }

        public DataTable Sorteo()
        {
            DataTable tabla = new DataTable();
            cnn.Open();
            SqlCommand cmd = new SqlCommand("SP_SORTEO", cnn);
            cmd.CommandType = CommandType.StoredProcedure;
            tabla.Load(cmd.ExecuteReader());
            cnn.Close();
            return tabla;
        }


    }
}
